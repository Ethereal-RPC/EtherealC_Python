class ServiceNode:
    def __init__(self):
        self.name = None
