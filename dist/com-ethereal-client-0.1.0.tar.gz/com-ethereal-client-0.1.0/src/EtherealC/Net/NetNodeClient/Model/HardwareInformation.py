class HardwareInformation:
    def __init__(self):
        self.OSDescription = None
        self.OSArchitecture = None
        self.ProcessArchitecture = None
        self.Is64BitOperatingSystem = None
        self.NetworkInterfaces = None
