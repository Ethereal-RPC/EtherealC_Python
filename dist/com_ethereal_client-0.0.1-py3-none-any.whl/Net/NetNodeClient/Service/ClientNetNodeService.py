class ClientNetNodeService:
    def __init__(self):
        pass
