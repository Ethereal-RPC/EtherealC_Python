from Net.Abstract.NetConfig import NetConfig


class WebSocketNetConfig(NetConfig):

    def __init__(self):
        super().__init__()
