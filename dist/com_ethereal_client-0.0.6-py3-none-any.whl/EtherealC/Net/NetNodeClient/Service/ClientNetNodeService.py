from EtherealC.Service.WebSocket.WebSocketService import WebSocketService


class ClientNetNodeService(WebSocketService):
    def __init__(self):
        super().__init__()
