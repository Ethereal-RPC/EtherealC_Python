from EtherealC.Service.Abstract.Service import Service


class WebSocketService(Service):
    def __init__(self):
        super().__init__()
