class RequestNode:
    def __init__(self):
        self.name = None
