from EtherealC.Core.Model.AbstractTypes import AbstractTypes
from EtherealC.Request.Abstract.RequestConfig import RequestConfig


class WebSocketRequestConfig(RequestConfig):

    def __init__(self):
        super().__init__()


