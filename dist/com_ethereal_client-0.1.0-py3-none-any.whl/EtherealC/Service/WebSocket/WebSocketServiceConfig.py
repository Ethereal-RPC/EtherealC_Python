from EtherealC.Core.Model.AbstractTypes import AbstractTypes
from EtherealC.Service.Abstract.ServiceConfig import ServiceConfig


class WebSocketServiceConfig(ServiceConfig):

    def __init__(self):
        super().__init__()
