class AbstrackType:
    def __init__(self):
        self.deserialize = None
        self.serialize = None
        self.type = None
        self.name = None
