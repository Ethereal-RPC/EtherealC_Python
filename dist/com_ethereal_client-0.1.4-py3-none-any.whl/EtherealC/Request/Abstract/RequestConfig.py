from EtherealC.Core.Model.AbstractTypes import AbstractTypes


class RequestConfig:

    def __init__(self):
        self.timeout = -1
